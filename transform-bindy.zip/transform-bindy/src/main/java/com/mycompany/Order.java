package com.mycompany;

import java.io.Serializable;

import org.apache.camel.dataformat.bindy.annotation.CsvRecord;
import org.apache.camel.dataformat.bindy.annotation.DataField;

@CsvRecord(separator = ",", crlf = "WINDOWS")
public class Order implements Serializable {

	private static final long serialVersionUID = -1725629003198083340L;
	@DataField(pos = 1)
	int id;
	@DataField(pos = 2)
	String description;
	@DataField(pos = 3)
	double price;
	@DataField(pos = 4)
	double tax;

}
