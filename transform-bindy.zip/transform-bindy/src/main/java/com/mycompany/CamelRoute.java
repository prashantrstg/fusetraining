package com.mycompany;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.dataformat.bindy.csv.BindyCsvDataFormat;
import org.apache.camel.spi.DataFormat;

public class CamelRoute extends RouteBuilder {

	@Override
	public void configure() throws Exception {
		BindyCsvDataFormat dataFormat=new BindyCsvDataFormat(Order.class);
		
		from("file:in").unmarshal(dataFormat).to("jms:queue:orders");
		
	}
}
