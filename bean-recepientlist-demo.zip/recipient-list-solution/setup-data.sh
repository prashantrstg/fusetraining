#!/bin/bash

echo "No configuration is needed. Please proceed with your lab"