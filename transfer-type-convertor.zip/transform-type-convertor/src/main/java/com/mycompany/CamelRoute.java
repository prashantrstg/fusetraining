package com.mycompany;

import org.apache.camel.builder.RouteBuilder;

public class CamelRoute extends RouteBuilder {

	@Override
	public void configure() throws Exception {
		from("file:in?noop=true").convertBodyTo(Order.class).to("velocity:template/email.vm").to("file:out");

	}
}
