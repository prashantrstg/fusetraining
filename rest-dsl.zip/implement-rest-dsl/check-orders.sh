#!/bin/bash
mysql --host=services -ubookstore -predhat -t -e "select id, orderDate from bookstore.order_;"
