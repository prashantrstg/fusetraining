#!/bin/bash
mysql --host=services -ubookstore -predhat -t -e "select id, order_id, extPrice,  quantity from bookstore.OrderItem;"
