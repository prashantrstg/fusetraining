package com.redhat.training.camel.error;

import org.apache.camel.builder.RouteBuilder;

public class ErrorHandlingRouteBuilder extends RouteBuilder {

	@Override
	public void configure() throws Exception {
		
		onException(NumberFormatException.class).routeId("numberFormatException").to("file:orders/tmp").handled(true);

		errorHandler(deadLetterChannel("file:orders/trash").disableRedelivery());
		
		from("file:orders/incoming")
		.routeId("errorProcess")
			.doTry()
				.process(new AmountProcessor())
				.to("direct:process")
			.doCatch(NumberFormatException.class)
				.to("file:orders/error")
			.endDoTry();
		
		from("direct:process")
		.routeId("directoryPermissionError")
			.process(new PriceProcessor())
		.to("file:orders/root/dest");

	}

}
