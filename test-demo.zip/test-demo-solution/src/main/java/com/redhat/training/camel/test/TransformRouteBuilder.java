package com.redhat.training.camel.test;

import org.apache.camel.builder.RouteBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TransformRouteBuilder extends RouteBuilder {
	
	Logger log = LoggerFactory.getLogger(this.getClass());

	@Override
	public void configure() throws Exception {
		from("direct:orderInput")
		.routeId("process")
		.filter(new AdminOrderFilter())
		.to("file:orders/admin");
		
	}
	
	

}
