package com.redhat.training.camel.test;

import java.io.StringWriter;
import java.math.BigDecimal;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.camel.EndpointInject;
import org.apache.camel.Exchange;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.RoutesBuilder;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.builder.NotifyBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.redhat.training.camel.test.model.Address;
import com.redhat.training.camel.test.model.CatalogItem;
import com.redhat.training.camel.test.model.Customer;
import com.redhat.training.camel.test.model.Order;
import com.redhat.training.camel.test.model.OrderItem;

public class TransformRouteTest extends CamelTestSupport {

	Logger log = LoggerFactory.getLogger(this.getClass());

	@Produce(uri="direct:orderInput")
	private ProducerTemplate producer;
	
	@EndpointInject(uri = "mock:admin")
	private MockEndpoint destination;
	
	@Override
	public boolean isUseAdviceWith() {
		return true;
	}
	
	@Override
	protected RoutesBuilder createRouteBuilder() throws Exception {
		return new TransformRouteBuilder();
	}

	@Before
	public void before() throws Exception {
		deleteDirectory("orders");
		AdviceWithRouteBuilder mockRoute = new AdviceWithRouteBuilder() {
			
			@Override
			public void configure() throws Exception {
				interceptSendToEndpoint("file:orders/admin").skipSendToOriginalEndpoint().to("mock:admin");
			}
		};
		context.getRouteDefinition("process").adviceWith(context, mockRoute);
		context.start();

	}
	
	@After
	public void after() throws Exception {
		context.stop();
	}

	@Test
	public void testNonAdminOrder() throws Exception {
		NotifyBuilder builder = new NotifyBuilder(context).whenDone(1).create();
		builder.matches(2000, TimeUnit.MILLISECONDS);

		Order testNonAdminOrder = createTestOrder(false);

		String nonAdminXML = getExpectedXmlString(testNonAdminOrder);

		producer.sendBodyAndHeader(nonAdminXML, Exchange.FILE_NAME, "output.xml");
		destination.expectedMessageCount(1);
		assertMockEndpointsSatisfied();
		

	}

	@Test
	public void testAdminOrder() throws Exception {
		NotifyBuilder builder = new NotifyBuilder(context).whenDone(1).create();
		builder.matches(2000, TimeUnit.MILLISECONDS);

		// create order objects to test with as an admin user
		Order testAdminOrder = createTestOrder(true);
		String adminXML = getExpectedXmlString(testAdminOrder);

		// set nothing as the expected bodies received
		producer.sendBodyAndHeader(adminXML, Exchange.FILE_NAME, "output.xml");
		destination.expectedMessageCount(0);
		assertMockEndpointsSatisfied();
		

	}

	/**
	 * Creates a test Order with dummy data for testing.
	 * 
	 * @return Order a test Order object
	 */
	private Order createTestOrder(boolean isAdmin) {
		Address testAddress = createAddress();
		Customer testCustomer = createCustomer(isAdmin, testAddress);

		CatalogItem testCatalogItem = createCatalogItem("Yann Martel", "Fiction",
				"After deciding to sell their zoo in India and move to Canada, "
						+ "Santosh and Gita Patel board a freighter with their sons and a few remaining animals. "
						+ "Tragedy strikes when a terrible storm sinks the ship, leaving the Patels' teenage son, "
						+ "Pi, as the only human survivor. However, Pi is not alone; a fearsome Bengal "
						+ "tiger has also found refuge aboard the lifeboat. As days turn into weeks and weeks drag into "
						+ "months, Pi and the tiger must learn to trust each other if both are to survive.",
				"books/lifeofpi/cover.jpg", true, new BigDecimal("15.99"), "1234567", "Life of Pi");

		OrderItem testItem = createOrderItem(testCatalogItem, new BigDecimal("5.99"), 1);

		Order testOrder = createOrder(testCustomer, testItem);

		return testOrder;
	}

	private Order createOrder(Customer testCustomer, OrderItem testItem) {
		Order testOrder = new Order();
		testOrder.setDelivered(false);
		testOrder.setOrderDate(new Date());
		testOrder.setCustomer(testCustomer);
		testOrder.getItems().add(testItem);
		return testOrder;
	}

	private OrderItem createOrderItem(CatalogItem testCatalogItem, BigDecimal extPrice, int quantity) {
		OrderItem testItem = new OrderItem();
		testItem.setExtPrice(extPrice);
		testItem.setItem(testCatalogItem);
		testItem.setQuantity(quantity);
		return testItem;
	}

	private CatalogItem createCatalogItem(String author, String category, String description, String imagePath,
			boolean newItem, BigDecimal price, String sku, String title) {
		CatalogItem testCatalogItem = new CatalogItem();
		testCatalogItem.setAuthor(author);
		testCatalogItem.setCategory(category);
		testCatalogItem.setDescription(description);
		testCatalogItem.setImagePath(imagePath);
		testCatalogItem.setNewItem(newItem);
		testCatalogItem.setPrice(price);
		testCatalogItem.setSku(sku);
		testCatalogItem.setTitle(title);
		return testCatalogItem;
	}

	private Customer createCustomer(boolean isAdmin, Address testAddress) {
		Customer testCustomer = new Customer();
		testCustomer.setAdmin(isAdmin);
		testCustomer.setBillingAddress(testAddress);
		testCustomer.setShippingAddress(testAddress);
		testCustomer.setEmail("tester@redhat.com");
		testCustomer.setFirstName("Bob");
		testCustomer.setLastName("Tester");
		testCustomer.setPassword("password");
		testCustomer.setUsername("tester1");
		return testCustomer;
	}

	private Address createAddress() {
		Address testAddress = new Address();
		testAddress.setCity("Raleigh");
		testAddress.setCountry("USA");
		testAddress.setPostalCode("27601");
		testAddress.setState("NC");
		testAddress.setStreetAddress1("100 E. Davie Street");
		return testAddress;
	}

	/**
	 * Marshals an Order object into XML and returns the result as a String
	 * 
	 * @param order
	 *            Order object to be converted to XML
	 * @return String of the marshaled XML
	 * @throws JAXBException
	 */
	private String getExpectedXmlString(Order order) throws JAXBException {
		JAXBContext jaxbContext = JAXBContext.newInstance(Order.class);
		StringWriter sw = new StringWriter();
		Marshaller marshaller = jaxbContext.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		marshaller.marshal(order, sw);
		return sw.toString();
	}

}
