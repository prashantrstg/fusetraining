Camel Project for Spring 
=========================================

To build this project use

    mvn install

To run the project you can execute the following Maven goal

    mvn camel:run

For more help see the Apache Camel documentation

    https://camel.apache.org/
