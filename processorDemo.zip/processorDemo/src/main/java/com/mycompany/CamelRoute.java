package com.mycompany;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;

public class CamelRoute extends RouteBuilder {

	@Override
	public void configure() throws Exception {
	//	from("file:in").process(new MyProcessor()).to("file:out");
		from("file:in").process(new Processor() {
			
			@Override
			public void process(Exchange exchange) throws Exception {
				String payload=exchange.getIn().getBody(String.class);
				payload=payload.toUpperCase();
				exchange.getIn().setBody(payload);

				
			}
		}).to("file:out");
		
	}
}
