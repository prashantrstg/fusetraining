package com.redhat.training.camel.routes;

import java.net.ConnectException;

import javax.sql.DataSource;

import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.test.spring.CamelSpringTestSupport;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

public class JmsRouteTest extends CamelSpringTestSupport{


	@Produce(uri = "file:"+JmsRouteBuilder.DIRECTORY)
	private ProducerTemplate fileTemplate;

	private JdbcTemplate jdbc;

	@Before
	public void before() throws Exception {
		DataSource ds = context.getRegistry().lookupByNameAndType("atomikosDataSource", DataSource.class);
		jdbc = new JdbcTemplate(ds);
		System.setProperty("org.apache.activemq.SERIALIZABLE_PACKAGES", "*");
		deleteDirectory(JmsRouteBuilder.DIRECTORY);

	}

	@After
	public void after() throws Exception {
		context.stop();
		if (jdbc != null) {
			jdbc.execute("drop table order_");
		}

	}

	@Test
	public void testDelivery() throws Exception {
		context.start();
		fileTemplate.sendBody(VALID_ORDER);
		Thread.sleep(2000);
		int rows = jdbc.queryForObject("select count(1) from order_", Integer.class);
		Assert.assertEquals(0, rows);
	}

	@Test
	public void testRedelivery() throws Exception {
		context.getRouteDefinition("MessageToDB").adviceWith(context, new RouteBuilder() {
			public void configure() {
				interceptSendToEndpoint("jms:*").choice().when(header("JMSRedelivered").isEqualTo("false"))
						.throwException(new ConnectException("Cannot connect to the database"));
			}

		});
		context.start();
		fileTemplate.sendBody(INVALID_ORDER);
		Thread.sleep(2000);
		int rows = jdbc.queryForObject("select count(1) from order_", Integer.class);
		Assert.assertEquals(1, rows);

	}

	private static final String VALID_ORDER = "<order>" + "<name>Mr. John Doe</name>" + "<discount>10</discount>"
			+ "</order>";
	private static final String INVALID_ORDER = "<order>" + "<name>Mr. John Doe</name>" + "<discount>150</discount>"
			+ "</order>";

	@Override
	public boolean isUseAdviceWith() {
		return true;
	}
	@Override
	protected AbstractApplicationContext createApplicationContext() {
		return new ClassPathXmlApplicationContext("/META-INF/spring/camel-context.xml");
	}

}
