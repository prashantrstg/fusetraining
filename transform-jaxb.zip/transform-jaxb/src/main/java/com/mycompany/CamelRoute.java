package com.mycompany;

import javax.xml.bind.JAXBContext;

import org.apache.camel.builder.RouteBuilder;
//import org.apache.camel.model.dataformat.JaxbDataFormat;
import org.apache.camel.converter.jaxb.JaxbDataFormat;

public class CamelRoute extends RouteBuilder {

	@Override
	public void configure() throws Exception {
		// JaxbDataFormat jaxbDataFormat=new JaxbDataFormat();
		JaxbDataFormat jaxbDataFormat = new JaxbDataFormat();
		JAXBContext context = JAXBContext.newInstance(Order.class);
		jaxbDataFormat.setContext(context);

		from("file:in").unmarshal(jaxbDataFormat).to("jms:queue:orders");

	}
}
