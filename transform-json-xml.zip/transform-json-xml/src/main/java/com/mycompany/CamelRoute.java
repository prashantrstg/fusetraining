package com.mycompany;

import javax.xml.bind.JAXBContext;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.converter.jaxb.JaxbDataFormat;

import org.apache.camel.component.jackson.JacksonDataFormat;

public class CamelRoute extends RouteBuilder {

	@Override
	public void configure() throws Exception {
		JaxbDataFormat jaxbDataFormat = new JaxbDataFormat();
		JAXBContext context = JAXBContext.newInstance(Payment.class);
		jaxbDataFormat.setContext(context);

		JacksonDataFormat jacksonDataFormat = new JacksonDataFormat(Payment.class);

		from("file:in?noop=true").split(xpath("/payments/payment")).unmarshal(jaxbDataFormat).marshal(jacksonDataFormat)
				.to("file:out?fileExist=Append");

	}
}
