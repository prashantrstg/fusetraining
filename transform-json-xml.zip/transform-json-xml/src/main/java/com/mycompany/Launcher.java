package com.mycompany;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.camel.CamelContext;
import org.apache.camel.component.jms.JmsComponent;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.main.Main;

public class Launcher {
    /**
     * A main() so we can easily run these routing rules in our IDE
     */
    public static void main(String... args) throws Exception {
    	CamelContext context = new DefaultCamelContext();
		// Define JMS component with ActiveMQ factory
//		ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(
//				"vm://localhost");
//		connectionFactory.setTrustAllPackages(true);
//		context.addComponent("jms",
//				JmsComponent.jmsComponentAutoAcknowledge(connectionFactory));
//
		context.addRoutes(new CamelRoute());
		context.start();
		Thread.sleep(5000);
		context.stop();
    }
}
