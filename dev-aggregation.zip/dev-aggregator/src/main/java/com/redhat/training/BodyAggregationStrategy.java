package com.redhat.training;

import org.apache.camel.Exchange;
import org.apache.camel.processor.aggregate.AggregationStrategy;

final class BodyAggregationStrategy implements AggregationStrategy {
	@Override
	public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {

		if (oldExchange == null)
			return newExchange;
		String oldBody = oldExchange.getIn().getBody(String.class);
		String newBody = newExchange.getIn().getBody(String.class);
		newBody = newBody.concat(oldBody);
		newExchange.getIn().setBody(newBody);
	//	newExchange.getIn().setHeader(Exchange.AGGREGATION_COMPLETE_ALL_GROUPS,true);
		return newExchange;
	}
}