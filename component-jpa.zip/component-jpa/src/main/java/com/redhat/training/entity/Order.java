package com.redhat.training.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.camel.dataformat.bindy.annotation.CsvRecord;
import org.apache.camel.dataformat.bindy.annotation.DataField;

@Entity

@Table(schema = "LPG_db", name = "orders")
@CsvRecord(separator = ",", crlf = "WINDOWS")
public class Order implements Serializable {

	private static final long serialVersionUID = -1918022935493323483L;

	/*
	 * @Id
	 * 
	 * @DataField(pos=1) private int id;
	 * 
	 * @DataField(pos=2) private String description;
	 * 
	 * @DataField(pos=3) private double tax;
	 * 
	 * @DataField(pos=4) private double price;
	 * 
	 * 
	 * public int getId() { return id; }
	 */
	@Id
	@DataField(pos = 1)
	private int id;
	@DataField(pos = 2)
	private int Cust_id;
	@DataField(pos = 3)
	private String date;
	@DataField(pos = 4)
	private int quantity;
	@DataField(pos = 5)
	private String Payment_Type;
	@DataField(pos = 6)
	private String status;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getCust_id() {
		return Cust_id;
	}
	public void setCust_id(int cust_id) {
		Cust_id = cust_id;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getPayment_Type() {
		return Payment_Type;
	}
	public void setPayment_Type(String payment_Type) {
		Payment_Type = payment_Type;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}


	

}
