package com.redhat.training;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.BindyType;

import com.redhat.training.entity.Order;

public class JpaRouteBuilder extends RouteBuilder {

	@Override
	public void configure() throws Exception {
		//from("timer:orderfilegenerator")
				from("jpa:com.redhat.training.entity.Order?persistenceUnit=component-jpa&consumeDelete=false").marshal()
				.bindy(BindyType.Csv, Order.class).to("file:out?fileName=orders.txt&fileExist=Append");

	}

}
