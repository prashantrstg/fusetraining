package com.redhat.training.jb421;

import org.apache.camel.builder.RouteBuilder;

public class RestRouteBuilder extends RouteBuilder {

	@Override
	public void configure() throws Exception {

		rest("/hello")
		    .get("{name}")
		    .produces("application/json")
		       .to("direct:sayHello");

		from("direct:sayHello").routeId("HelloREST")
			.setBody().simple("{\n"
			    + "  greeting: Hello, ${header.name}\n"
			    + "  server: " + System.getenv("HOSTNAME") + "\n"
			    + "}\n");
	}

}
